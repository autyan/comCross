import { X, Usb } from 'lucide-react';
import { useState } from 'react';
import { Device } from '@/app/types';

interface ConnectDialogProps {
  isOpen: boolean;
  devices: Device[];
  onClose: () => void;
  onConnect: (port: string, baudRate: number, name: string) => void;
}

const COMMON_BAUD_RATES = [9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600];

export function ConnectDialog({ isOpen, devices, onClose, onConnect }: ConnectDialogProps) {
  const [selectedPort, setSelectedPort] = useState(devices[0]?.port || '');
  const [baudRate, setBaudRate] = useState(115200);
  const [sessionName, setSessionName] = useState('');

  if (!isOpen) return null;

  const handleConnect = () => {
    const device = devices.find(d => d.port === selectedPort);
    const name = sessionName.trim() || device?.name || selectedPort;
    onConnect(selectedPort, baudRate, name);
    onClose();
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{ background: 'rgba(0, 0, 0, 0.7)' }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-lg shadow-2xl"
        style={{ 
          background: 'var(--bg-1)',
          border: '1px solid var(--border)',
          boxShadow: '0 8px 20px var(--shadow)'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div 
          className="h-14 px-4 flex items-center justify-between border-b"
          style={{ borderColor: 'var(--border)' }}
        >
          <h2 className="flex items-center gap-2">
            <Usb size={20} style={{ color: 'var(--accent)' }} />
            Connect to Device
          </h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded flex items-center justify-center hover:opacity-80"
            style={{ color: 'var(--text-2)' }}
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {/* Device Selection */}
          <div>
            <label className="block mb-2">Select Device</label>
            <select
              value={selectedPort}
              onChange={(e) => {
                setSelectedPort(e.target.value);
                const device = devices.find(d => d.port === e.target.value);
                if (device && !sessionName) {
                  setSessionName(device.name);
                }
              }}
              className="w-full px-3 py-2 rounded outline-none"
              style={{
                background: 'var(--bg-0)',
                color: 'var(--text-0)',
                border: '1px solid var(--border)',
                borderRadius: 'var(--radius-input)'
              }}
            >
              {devices.map((device) => (
                <option key={device.port} value={device.port}>
                  {device.name} ({device.port})
                </option>
              ))}
            </select>
          </div>

          {/* Baud Rate */}
          <div>
            <label className="block mb-2">Baud Rate</label>
            <select
              value={baudRate}
              onChange={(e) => setBaudRate(Number(e.target.value))}
              className="w-full px-3 py-2 rounded outline-none"
              style={{
                background: 'var(--bg-0)',
                color: 'var(--text-0)',
                border: '1px solid var(--border)',
                borderRadius: 'var(--radius-input)'
              }}
            >
              {COMMON_BAUD_RATES.map((rate) => (
                <option key={rate} value={rate}>
                  {rate}
                </option>
              ))}
            </select>
          </div>

          {/* Session Name */}
          <div>
            <label className="block mb-2">Session Name (Optional)</label>
            <input
              type="text"
              value={sessionName}
              onChange={(e) => setSessionName(e.target.value)}
              placeholder="e.g., STM32 Debug"
              className="w-full px-3 py-2 rounded outline-none"
              style={{
                background: 'var(--bg-0)',
                color: 'var(--text-0)',
                border: '1px solid var(--border)',
                borderRadius: 'var(--radius-input)'
              }}
            />
          </div>

          {/* Info Box */}
          <div 
            className="p-3 rounded"
            style={{ 
              background: 'rgba(44, 181, 169, 0.1)',
              border: '1px solid var(--accent)'
            }}
          >
            <p style={{ color: 'var(--text-1)', fontSize: 'var(--text-caption)' }}>
              Connection will open in a new session tab. You can manage multiple sessions simultaneously.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div 
          className="h-16 px-6 flex items-center justify-end gap-2 border-t"
          style={{ 
            background: 'var(--bg-2)',
            borderColor: 'var(--border)' 
          }}
        >
          <button
            onClick={onClose}
            className="px-4 py-2 rounded transition-colors hover:opacity-80"
            style={{
              background: 'transparent',
              color: 'var(--text-1)',
              border: '1px solid var(--border)'
            }}
          >
            Cancel
          </button>
          <button
            onClick={handleConnect}
            disabled={!selectedPort}
            className="px-4 py-2 rounded transition-colors disabled:opacity-40"
            style={{
              background: 'var(--accent)',
              color: 'white',
            }}
          >
            Connect
          </button>
        </div>
      </div>
    </div>
  );
}
