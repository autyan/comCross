import { Star, Usb, Circle, ChevronDown, ChevronRight, Radio } from 'lucide-react';
import { Device, Session, Listener } from '@/app/types';
import { useState } from 'react';

interface LeftSidebarProps {
  devices: Device[];
  sessions: Session[];
  listeners: Listener[];
  activeSessionId: string | null;
  onSessionSelect: (sessionId: string) => void;
  onDeviceClick: (device: Device) => void;
}

export function LeftSidebar({ 
  devices, 
  sessions, 
  listeners,
  activeSessionId, 
  onSessionSelect,
  onDeviceClick 
}: LeftSidebarProps) {
  const favoriteDevices = devices.filter(d => d.isFavorite);
  const otherDevices = devices.filter(d => !d.isFavorite);
  const [collapsedListeners, setCollapsedListeners] = useState<Set<string>>(new Set());

  const toggleListener = (listenerId: string) => {
    setCollapsedListeners(prev => {
      const next = new Set(prev);
      if (next.has(listenerId)) {
        next.delete(listenerId);
      } else {
        next.add(listenerId);
      }
      return next;
    });
  };

  // Group sessions by listener
  const standaloneSessions = sessions.filter(s => !s.listenerId);
  const sessionsByListener = listeners.map(listener => ({
    listener,
    sessions: sessions.filter(s => s.listenerId === listener.id)
  }));

  return (
    <div 
      className="w-64 border-r flex flex-col overflow-hidden"
      style={{ background: 'var(--bg-1)', borderColor: 'var(--border)' }}
    >
      {/* Sessions */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-3" style={{ borderBottom: '1px solid var(--border)' }}>
          <h3 className="mb-3">Active Sessions</h3>
          {sessions.length === 0 && listeners.length === 0 ? (
            <p style={{ color: 'var(--text-2)', fontSize: 'var(--text-caption)' }}>
              No active sessions
            </p>
          ) : (
            <div className="space-y-2">
              {/* Listeners with their child sessions */}
              {sessionsByListener.map(({ listener, sessions: childSessions }) => (
                <div key={listener.id} className="space-y-1">
                  {/* Listener Header */}
                  <button
                    onClick={() => toggleListener(listener.id)}
                    className="w-full px-2 py-1.5 rounded text-left transition-colors flex items-center gap-2"
                    style={{
                      background: 'var(--bg-2)',
                      color: 'var(--text-1)',
                      border: '1px solid var(--border)'
                    }}
                  >
                    {collapsedListeners.has(listener.id) ? (
                      <ChevronRight size={14} style={{ color: 'var(--text-2)' }} />
                    ) : (
                      <ChevronDown size={14} style={{ color: 'var(--text-2)' }} />
                    )}
                    <Radio 
                      size={12} 
                      style={{ 
                        color: listener.status === 'listening' ? 'var(--success)' : 'var(--text-2)' 
                      }} 
                    />
                    <div className="flex-1 flex items-center justify-between">
                      <span style={{ fontSize: 'var(--text-caption)' }}>{listener.name}</span>
                      <span style={{ 
                        fontSize: 'var(--text-caption)', 
                        color: 'var(--text-2)',
                        fontFamily: 'var(--font-mono)'
                      }}>
                        {listener.protocol}:{listener.port}
                      </span>
                    </div>
                  </button>

                  {/* Child Sessions */}
                  {!collapsedListeners.has(listener.id) && childSessions.length > 0 && (
                    <div className="ml-4 space-y-1" style={{ 
                      borderLeft: '2px solid var(--border)',
                      paddingLeft: '8px'
                    }}>
                      {childSessions.map(session => (
                        <button
                          key={session.id}
                          onClick={() => onSessionSelect(session.id)}
                          className="w-full px-3 py-2 rounded text-left transition-colors relative"
                          style={{
                            background: activeSessionId === session.id ? 'var(--accent-2)' : 'transparent',
                            color: activeSessionId === session.id ? 'white' : 'var(--text-1)',
                          }}
                        >
                          {activeSessionId === session.id && (
                            <div 
                              className="absolute left-0 top-0 bottom-0 w-1 rounded-r"
                              style={{ background: 'var(--accent-2)' }}
                            />
                          )}
                          <div className="flex items-center justify-between mb-1">
                            <span className="flex items-center gap-2">
                              <Circle 
                                size={8} 
                                fill={session.status === 'connected' ? 'var(--success)' : 'var(--text-2)'}
                                style={{ color: session.status === 'connected' ? 'var(--success)' : 'var(--text-2)' }}
                              />
                              {session.name}
                            </span>
                          </div>
                          <div style={{ fontSize: 'var(--text-caption)', opacity: 0.8 }}>
                            {session.port}
                          </div>
                        </button>
                      ))}
                    </div>
                  )}

                  {/* Empty state when collapsed or no sessions */}
                  {!collapsedListeners.has(listener.id) && childSessions.length === 0 && (
                    <div className="ml-4 px-3 py-2" style={{ 
                      color: 'var(--text-2)', 
                      fontSize: 'var(--text-caption)',
                      borderLeft: '2px solid var(--border)',
                      paddingLeft: '8px'
                    }}>
                      No connected clients
                    </div>
                  )}
                </div>
              ))}

              {/* Standalone sessions (Serial, etc.) */}
              {standaloneSessions.length > 0 && (
                <div className="space-y-1">
                  {listeners.length > 0 && (
                    <div 
                      className="px-2 py-1" 
                      style={{ 
                        color: 'var(--text-2)', 
                        fontSize: 'var(--text-caption)',
                        borderTop: listeners.length > 0 ? '1px solid var(--border)' : 'none',
                        marginTop: listeners.length > 0 ? '8px' : '0',
                        paddingTop: listeners.length > 0 ? '8px' : '0'
                      }}
                    >
                      Direct Connections
                    </div>
                  )}
                  {standaloneSessions.map(session => (
                    <button
                      key={session.id}
                      onClick={() => onSessionSelect(session.id)}
                      className="w-full px-3 py-2 rounded text-left transition-colors relative"
                      style={{
                        background: activeSessionId === session.id ? 'var(--accent-2)' : 'transparent',
                        color: activeSessionId === session.id ? 'white' : 'var(--text-1)',
                      }}
                    >
                      {activeSessionId === session.id && (
                        <div 
                          className="absolute left-0 top-0 bottom-0 w-1 rounded-r"
                          style={{ background: 'var(--accent-2)' }}
                        />
                      )}
                      <div className="flex items-center justify-between mb-1">
                        <span className="flex items-center gap-2">
                          <Circle 
                            size={8} 
                            fill={session.status === 'connected' ? 'var(--success)' : 'var(--text-2)'}
                            style={{ color: session.status === 'connected' ? 'var(--success)' : 'var(--text-2)' }}
                          />
                          {session.name}
                        </span>
                      </div>
                      <div style={{ fontSize: 'var(--text-caption)', opacity: 0.8 }}>
                        {session.port}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Favorite Devices */}
        {favoriteDevices.length > 0 && (
          <div className="p-3" style={{ borderBottom: '1px solid var(--border)' }}>
            <h4 className="mb-3 flex items-center gap-2">
              <Star size={14} style={{ color: 'var(--warn)' }} />
              Favorites
            </h4>
            <div className="space-y-1">
              {favoriteDevices.map(device => (
                <button
                  key={device.port}
                  onClick={() => onDeviceClick(device)}
                  className="w-full px-3 py-2 rounded text-left transition-colors hover:opacity-80"
                  style={{
                    background: 'transparent',
                    color: 'var(--text-1)',
                    border: '1px solid var(--border)'
                  }}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Usb size={14} />
                    <span>{device.name}</span>
                  </div>
                  <div style={{ fontSize: 'var(--text-caption)', color: 'var(--text-2)' }}>
                    {device.port}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* All Devices */}
        <div className="p-3">
          <h4 className="mb-3">Available Devices</h4>
          <div className="space-y-1">
            {otherDevices.map(device => (
              <button
                key={device.port}
                onClick={() => onDeviceClick(device)}
                className="w-full px-3 py-2 rounded text-left transition-colors hover:opacity-80"
                style={{
                  background: 'transparent',
                  color: 'var(--text-1)',
                  border: '1px solid var(--border)'
                }}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Usb size={14} />
                  <span>{device.name}</span>
                </div>
                <div style={{ fontSize: 'var(--text-caption)', color: 'var(--text-2)' }}>
                  {device.port}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}