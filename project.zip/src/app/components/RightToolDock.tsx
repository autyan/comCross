import { Send, Filter, Highlighter, Download, X } from 'lucide-react';
import { ToolType } from '@/app/types';
import { SendTool } from '@/app/components/tools/SendTool';
import { FilterTool } from '@/app/components/tools/FilterTool';
import { HighlightTool } from '@/app/components/tools/HighlightTool';
import { ExportTool } from '@/app/components/tools/ExportTool';

interface RightToolDockProps {
  activeTool: ToolType;
  onToolChange: (tool: ToolType) => void;
  isConnected: boolean;
}

export function RightToolDock({ activeTool, onToolChange, isConnected }: RightToolDockProps) {
  const tools = [
    { type: 'send' as const, icon: Send, label: 'Send' },
    { type: 'filter' as const, icon: Filter, label: 'Filter' },
    { type: 'highlight' as const, icon: Highlighter, label: 'Highlight' },
    { type: 'export' as const, icon: Download, label: 'Export' },
  ];

  return (
    <div className="flex h-full">
      {/* Tool Tabs */}
      <div 
        className="w-14 flex flex-col items-center py-3 gap-2 border-l"
        style={{ background: 'var(--bg-2)', borderColor: 'var(--border)' }}
      >
        {tools.map(({ type, icon: Icon, label }) => (
          <button
            key={type}
            onClick={() => onToolChange(activeTool === type ? null : type)}
            className="w-10 h-10 rounded flex items-center justify-center transition-colors relative group"
            style={{
              background: activeTool === type ? 'var(--accent-2)' : 'transparent',
              color: activeTool === type ? 'white' : 'var(--text-1)',
            }}
            title={label}
          >
            <Icon size={20} />
            {activeTool === type && (
              <div 
                className="absolute left-0 top-0 bottom-0 w-1 rounded-r"
                style={{ background: 'var(--accent-2)' }}
              />
            )}
          </button>
        ))}
      </div>

      {/* Tool Panel */}
      {activeTool && (
        <div 
          className="w-80 border-l flex flex-col overflow-hidden transition-all duration-200"
          style={{ background: 'var(--bg-1)', borderColor: 'var(--border)' }}
        >
          {/* Tool Header */}
          <div className="h-12 px-4 flex items-center justify-between border-b" style={{ borderColor: 'var(--border)' }}>
            <h3>{tools.find(t => t.type === activeTool)?.label}</h3>
            <button
              onClick={() => onToolChange(null)}
              className="w-6 h-6 rounded flex items-center justify-center hover:opacity-80"
              style={{ color: 'var(--text-2)' }}
            >
              <X size={16} />
            </button>
          </div>

          {/* Tool Content */}
          <div className="flex-1 overflow-y-auto">
            {activeTool === 'send' && <SendTool isConnected={isConnected} />}
            {activeTool === 'filter' && <FilterTool />}
            {activeTool === 'highlight' && <HighlightTool />}
            {activeTool === 'export' && <ExportTool />}
          </div>
        </div>
      )}
    </div>
  );
}
