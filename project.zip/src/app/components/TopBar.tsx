import { Play, Square, Trash2, Download } from 'lucide-react';
import { Session } from '@/app/types';

interface TopBarProps {
  activeSession: Session | null;
  onConnect: () => void;
  onDisconnect: () => void;
  onClear: () => void;
  onExport: () => void;
}

export function TopBar({ activeSession, onConnect, onDisconnect, onClear, onExport }: TopBarProps) {
  return (
    <div className="h-14 px-4 flex items-center justify-between border-b" style={{ 
      background: 'var(--bg-1)', 
      borderColor: 'var(--border)' 
    }}>
      {/* Left: App Title & Session Info */}
      <div className="flex items-center gap-4">
        <h1 className="flex items-center gap-2">
          <div className="w-8 h-8 rounded flex items-center justify-center" style={{ background: 'var(--accent)' }}>
            <div className="w-4 h-4 border-2 border-white rounded-sm" />
          </div>
          SuperCom
        </h1>
        
        {activeSession && (
          <>
            <div className="w-px h-6" style={{ background: 'var(--border)' }} />
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <div 
                  className="w-2 h-2 rounded-full" 
                  style={{ background: activeSession.status === 'connected' ? 'var(--success)' : 'var(--text-2)' }} 
                />
                <span style={{ color: 'var(--text-1)' }}>{activeSession.name}</span>
              </div>
              <span style={{ color: 'var(--text-2)', fontSize: 'var(--text-caption)' }}>
                {activeSession.port} @ {activeSession.baudRate}
              </span>
            </div>
          </>
        )}
      </div>

      {/* Right: Quick Actions */}
      <div className="flex items-center gap-2">
        <button
          onClick={onConnect}
          disabled={activeSession?.status === 'connected'}
          className="px-3 py-1.5 rounded flex items-center gap-2 transition-colors disabled:opacity-40"
          style={{
            background: activeSession?.status === 'connected' ? 'transparent' : 'var(--accent)',
            color: activeSession?.status === 'connected' ? 'var(--text-2)' : 'white',
            border: activeSession?.status === 'connected' ? '1px solid var(--border)' : 'none'
          }}
        >
          <Play size={14} />
          <span>Connect</span>
        </button>

        <button
          onClick={onDisconnect}
          disabled={activeSession?.status !== 'connected'}
          className="px-3 py-1.5 rounded flex items-center gap-2 transition-colors disabled:opacity-40"
          style={{
            background: 'transparent',
            color: 'var(--text-1)',
            border: '1px solid var(--border)'
          }}
        >
          <Square size={14} />
          <span>Disconnect</span>
        </button>

        <div className="w-px h-6 mx-1" style={{ background: 'var(--border)' }} />

        <button
          onClick={onClear}
          className="px-3 py-1.5 rounded flex items-center gap-2 transition-colors hover:opacity-80"
          style={{
            background: 'transparent',
            color: 'var(--text-1)',
            border: '1px solid var(--border)'
          }}
        >
          <Trash2 size={14} />
          <span>Clear</span>
        </button>

        <button
          onClick={onExport}
          className="px-3 py-1.5 rounded flex items-center gap-2 transition-colors hover:opacity-80"
          style={{
            background: 'transparent',
            color: 'var(--text-1)',
            border: '1px solid var(--border)'
          }}
        >
          <Download size={14} />
          <span>Export</span>
        </button>
      </div>
    </div>
  );
}
