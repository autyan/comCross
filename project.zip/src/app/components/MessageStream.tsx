import { Search, Filter, ArrowUp, ArrowDown } from 'lucide-react';
import { LogMessage, Session } from '@/app/types';
import { useEffect, useRef } from 'react';

interface MessageStreamProps {
  logs: LogMessage[];
  session: Session | null;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  showTimestamp: boolean;
}

export function MessageStream({ 
  logs, 
  session, 
  searchQuery, 
  onSearchChange,
  showTimestamp 
}: MessageStreamProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const formatTimestamp = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit',
      fractionalSecondDigits: 3 
    });
  };

  const formatBytes = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const formatDuration = (start: Date): string => {
    const seconds = Math.floor((Date.now() - start.getTime()) / 1000);
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getSourceColor = (source: LogMessage['source']) => {
    switch (source) {
      case 'RX': return 'var(--accent)';
      case 'TX': return 'var(--accent-2)';
      case 'SYSTEM': return 'var(--text-2)';
      case 'ERROR': return 'var(--error)';
      default: return 'var(--text-1)';
    }
  };

  const getLogStyle = (log: LogMessage) => {
    const baseStyle = {
      borderLeft: `3px solid ${getSourceColor(log.source)}`,
    };

    if (log.type === 'error') {
      return {
        ...baseStyle,
        background: 'rgba(229, 83, 75, 0.1)',
        color: 'var(--error)',
      };
    }

    if (log.type === 'warning') {
      return {
        ...baseStyle,
        background: 'rgba(245, 165, 36, 0.1)',
        color: 'var(--warn)',
      };
    }

    if (log.type === 'highlight') {
      return {
        ...baseStyle,
        background: 'rgba(44, 181, 169, 0.1)',
      };
    }

    return baseStyle;
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden" style={{ background: 'var(--bg-0)' }}>
      {/* Search & Filter Bar */}
      <div className="p-3 space-y-2" style={{ background: 'var(--bg-1)', borderBottom: '1px solid var(--border)' }}>
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search 
              size={16} 
              className="absolute left-3 top-1/2 -translate-y-1/2" 
              style={{ color: 'var(--text-2)' }}
            />
            <input
              type="text"
              placeholder="Search messages..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full pl-10 pr-3 py-2 rounded outline-none"
              style={{
                background: 'var(--bg-0)',
                color: 'var(--text-0)',
                border: '1px solid var(--border)',
                borderRadius: 'var(--radius-input)'
              }}
            />
          </div>
          <button
            className="px-3 py-2 rounded flex items-center gap-2 transition-colors hover:opacity-80"
            style={{
              background: 'transparent',
              color: 'var(--text-1)',
              border: '1px solid var(--border)'
            }}
          >
            <Filter size={16} />
          </button>
        </div>

        {/* Metrics Strip */}
        {session && (
          <div className="flex gap-4" style={{ fontSize: 'var(--text-caption)', color: 'var(--text-2)' }}>
            <div className="flex items-center gap-2">
              <ArrowDown size={12} style={{ color: 'var(--accent)' }} />
              <span>RX: {formatBytes(session.rxBytes)}</span>
            </div>
            <div className="flex items-center gap-2">
              <ArrowUp size={12} style={{ color: 'var(--accent-2)' }} />
              <span>TX: {formatBytes(session.txBytes)}</span>
            </div>
            {session.startTime && (
              <>
                <div className="w-px h-3" style={{ background: 'var(--border)' }} />
                <span>Elapsed: {formatDuration(session.startTime)}</span>
              </>
            )}
            <div className="w-px h-3" style={{ background: 'var(--border)' }} />
            <span>Lines: {logs.length}</span>
          </div>
        )}
      </div>

      {/* Log Stream */}
      <div className="flex-1 overflow-y-auto font-mono p-2" style={{ fontSize: 'var(--text-log)', lineHeight: 1.45 }}>
        {logs.length === 0 ? (
          <div className="h-full flex items-center justify-center" style={{ color: 'var(--text-2)' }}>
            <p>No messages yet. Connect to a device to start logging.</p>
          </div>
        ) : (
          <div className="space-y-px">
            {logs.map((log) => (
              <div
                key={log.id}
                className="px-3 py-1.5 flex gap-3"
                style={getLogStyle(log)}
              >
                {showTimestamp && (
                  <span style={{ color: 'var(--text-2)', minWidth: '100px' }}>
                    {formatTimestamp(log.timestamp)}
                  </span>
                )}
                <span 
                  className="font-medium" 
                  style={{ color: getSourceColor(log.source), minWidth: '60px' }}
                >
                  [{log.source}]
                </span>
                <span style={{ color: log.type === 'error' ? 'var(--error)' : 'var(--text-0)', flex: 1 }}>
                  {log.content}
                </span>
              </div>
            ))}
            <div ref={bottomRef} />
          </div>
        )}
      </div>
    </div>
  );
}
