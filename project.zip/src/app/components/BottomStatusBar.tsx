import { Cpu, HardDrive, Save, AlertCircle } from 'lucide-react';

interface BottomStatusBarProps {
  autoSaveEnabled: boolean;
  notifications: Array<{ id: string; type: 'info' | 'warning' | 'error'; message: string }>;
}

export function BottomStatusBar({ autoSaveEnabled, notifications }: BottomStatusBarProps) {
  return (
    <div 
      className="h-8 px-4 flex items-center justify-between border-t"
      style={{ 
        background: 'var(--bg-2)', 
        borderColor: 'var(--border)',
        fontSize: 'var(--text-caption)'
      }}
    >
      {/* Left: System Stats */}
      <div className="flex items-center gap-4" style={{ color: 'var(--text-2)' }}>
        <div className="flex items-center gap-1.5">
          <Cpu size={12} />
          <span>CPU: 12%</span>
        </div>
        <div className="flex items-center gap-1.5">
          <HardDrive size={12} />
          <span>MEM: 256 MB</span>
        </div>
        <div className="w-px h-4" style={{ background: 'var(--border)' }} />
        <div className="flex items-center gap-1.5">
          <Save size={12} style={{ color: autoSaveEnabled ? 'var(--success)' : 'var(--text-2)' }} />
          <span>Auto-save {autoSaveEnabled ? 'ON' : 'OFF'}</span>
        </div>
      </div>

      {/* Right: Notifications */}
      <div className="flex items-center gap-2">
        {notifications.map((notif) => (
          <div 
            key={notif.id}
            className="flex items-center gap-1.5 px-2 py-1 rounded"
            style={{ 
              background: 'rgba(245, 165, 36, 0.1)',
              color: notif.type === 'error' ? 'var(--error)' : notif.type === 'warning' ? 'var(--warn)' : 'var(--text-1)'
            }}
          >
            <AlertCircle size={12} />
            <span>{notif.message}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
