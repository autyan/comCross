import { Plus, Trash2, Power } from 'lucide-react';
import { useState } from 'react';
import { HighlightRule } from '@/app/types';

const PRESET_COLORS = [
  { name: 'Cyan', value: 'var(--accent)' },
  { name: 'Blue', value: 'var(--accent-2)' },
  { name: 'Yellow', value: 'var(--warn)' },
  { name: 'Red', value: 'var(--error)' },
  { name: 'Green', value: 'var(--success)' },
];

export function HighlightTool() {
  const [highlights, setHighlights] = useState<HighlightRule[]>([
    { id: '1', pattern: 'ERROR', isRegex: false, color: 'var(--error)', enabled: true },
    { id: '2', pattern: 'INFO', isRegex: false, color: 'var(--accent)', enabled: true },
  ]);
  const [newPattern, setNewPattern] = useState('');
  const [isRegex, setIsRegex] = useState(false);
  const [selectedColor, setSelectedColor] = useState(PRESET_COLORS[0].value);

  const handleAddHighlight = () => {
    if (!newPattern.trim()) return;
    const newHighlight: HighlightRule = {
      id: Date.now().toString(),
      pattern: newPattern,
      isRegex,
      color: selectedColor,
      enabled: true,
    };
    setHighlights([...highlights, newHighlight]);
    setNewPattern('');
  };

  const handleToggleHighlight = (id: string) => {
    setHighlights(highlights.map(h => 
      h.id === id ? { ...h, enabled: !h.enabled } : h
    ));
  };

  const handleDeleteHighlight = (id: string) => {
    setHighlights(highlights.filter(h => h.id !== id));
  };

  return (
    <div className="p-4 space-y-4">
      {/* Add Highlight */}
      <div>
        <label className="block mb-2">Add Highlight Rule</label>
        <div className="space-y-2">
          <input
            type="text"
            value={newPattern}
            onChange={(e) => setNewPattern(e.target.value)}
            placeholder="Pattern or keyword..."
            className="w-full px-3 py-2 rounded outline-none"
            style={{
              background: 'var(--bg-0)',
              color: 'var(--text-0)',
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius-input)',
              fontFamily: isRegex ? 'var(--font-mono)' : 'inherit'
            }}
          />

          <div>
            <label className="block mb-2" style={{ fontSize: 'var(--text-caption)' }}>Color</label>
            <div className="flex gap-2">
              {PRESET_COLORS.map((color) => (
                <button
                  key={color.value}
                  onClick={() => setSelectedColor(color.value)}
                  className="w-8 h-8 rounded border-2 transition-all"
                  style={{
                    background: color.value,
                    borderColor: selectedColor === color.value ? 'white' : 'transparent',
                    opacity: selectedColor === color.value ? 1 : 0.6
                  }}
                  title={color.name}
                />
              ))}
            </div>
          </div>

          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={isRegex}
              onChange={(e) => setIsRegex(e.target.checked)}
              className="w-4 h-4"
            />
            <span>Use Regular Expression</span>
          </label>
          <button
            onClick={handleAddHighlight}
            className="w-full px-4 py-2 rounded flex items-center justify-center gap-2 transition-colors"
            style={{
              background: 'var(--accent)',
              color: 'white',
            }}
          >
            <Plus size={16} />
            Add Highlight
          </button>
        </div>
      </div>

      {/* Highlight List */}
      <div>
        <label className="block mb-2">Active Highlights ({highlights.length})</label>
        {highlights.length === 0 ? (
          <p style={{ color: 'var(--text-2)', fontSize: 'var(--text-caption)' }}>
            No highlights added
          </p>
        ) : (
          <div className="space-y-2">
            {highlights.map((highlight) => (
              <div
                key={highlight.id}
                className="px-3 py-2 rounded flex items-center gap-2"
                style={{
                  background: 'var(--bg-0)',
                  border: '1px solid var(--border)',
                  opacity: highlight.enabled ? 1 : 0.5
                }}
              >
                <button
                  onClick={() => handleToggleHighlight(highlight.id)}
                  className="flex-shrink-0"
                  style={{ color: highlight.enabled ? 'var(--success)' : 'var(--text-2)' }}
                >
                  <Power size={16} />
                </button>
                <div
                  className="w-4 h-4 rounded flex-shrink-0"
                  style={{ background: highlight.color }}
                />
                <div className="flex-1 min-w-0">
                  <div 
                    className="truncate"
                    style={{ 
                      color: 'var(--text-0)',
                      fontFamily: highlight.isRegex ? 'var(--font-mono)' : 'inherit',
                      fontSize: 'var(--text-caption)'
                    }}
                  >
                    {highlight.pattern}
                  </div>
                  {highlight.isRegex && (
                    <div style={{ color: 'var(--text-2)', fontSize: 'var(--text-caption)' }}>
                      Regex
                    </div>
                  )}
                </div>
                <button
                  onClick={() => handleDeleteHighlight(highlight.id)}
                  className="flex-shrink-0 hover:opacity-80"
                  style={{ color: 'var(--error)' }}
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
