import { Plus, Trash2, Power } from 'lucide-react';
import { useState } from 'react';
import { FilterRule } from '@/app/types';

export function FilterTool() {
  const [filters, setFilters] = useState<FilterRule[]>([
    { id: '1', pattern: 'ERROR', isRegex: false, enabled: true },
    { id: '2', pattern: 'WARN', isRegex: false, enabled: true },
  ]);
  const [newPattern, setNewPattern] = useState('');
  const [isRegex, setIsRegex] = useState(false);

  const handleAddFilter = () => {
    if (!newPattern.trim()) return;
    const newFilter: FilterRule = {
      id: Date.now().toString(),
      pattern: newPattern,
      isRegex,
      enabled: true,
    };
    setFilters([...filters, newFilter]);
    setNewPattern('');
  };

  const handleToggleFilter = (id: string) => {
    setFilters(filters.map(f => 
      f.id === id ? { ...f, enabled: !f.enabled } : f
    ));
  };

  const handleDeleteFilter = (id: string) => {
    setFilters(filters.filter(f => f.id !== id));
  };

  return (
    <div className="p-4 space-y-4">
      {/* Add Filter */}
      <div>
        <label className="block mb-2">Add Filter Rule</label>
        <div className="space-y-2">
          <input
            type="text"
            value={newPattern}
            onChange={(e) => setNewPattern(e.target.value)}
            placeholder="Pattern or keyword..."
            className="w-full px-3 py-2 rounded outline-none"
            style={{
              background: 'var(--bg-0)',
              color: 'var(--text-0)',
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius-input)',
              fontFamily: isRegex ? 'var(--font-mono)' : 'inherit'
            }}
          />
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={isRegex}
              onChange={(e) => setIsRegex(e.target.checked)}
              className="w-4 h-4"
            />
            <span>Use Regular Expression</span>
          </label>
          <button
            onClick={handleAddFilter}
            className="w-full px-4 py-2 rounded flex items-center justify-center gap-2 transition-colors"
            style={{
              background: 'var(--accent)',
              color: 'white',
            }}
          >
            <Plus size={16} />
            Add Filter
          </button>
        </div>
      </div>

      {/* Filter List */}
      <div>
        <label className="block mb-2">Active Filters ({filters.length})</label>
        {filters.length === 0 ? (
          <p style={{ color: 'var(--text-2)', fontSize: 'var(--text-caption)' }}>
            No filters added
          </p>
        ) : (
          <div className="space-y-2">
            {filters.map((filter) => (
              <div
                key={filter.id}
                className="px-3 py-2 rounded flex items-center gap-2"
                style={{
                  background: 'var(--bg-0)',
                  border: '1px solid var(--border)',
                  opacity: filter.enabled ? 1 : 0.5
                }}
              >
                <button
                  onClick={() => handleToggleFilter(filter.id)}
                  className="flex-shrink-0"
                  style={{ color: filter.enabled ? 'var(--success)' : 'var(--text-2)' }}
                >
                  <Power size={16} />
                </button>
                <div className="flex-1 min-w-0">
                  <div 
                    className="truncate"
                    style={{ 
                      color: 'var(--text-0)',
                      fontFamily: filter.isRegex ? 'var(--font-mono)' : 'inherit',
                      fontSize: 'var(--text-caption)'
                    }}
                  >
                    {filter.pattern}
                  </div>
                  {filter.isRegex && (
                    <div style={{ color: 'var(--text-2)', fontSize: 'var(--text-caption)' }}>
                      Regex
                    </div>
                  )}
                </div>
                <button
                  onClick={() => handleDeleteFilter(filter.id)}
                  className="flex-shrink-0 hover:opacity-80"
                  style={{ color: 'var(--error)' }}
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Info */}
      <div 
        className="p-3 rounded"
        style={{ 
          background: 'rgba(58, 160, 255, 0.1)',
          border: '1px solid var(--accent-2)'
        }}
      >
        <p style={{ color: 'var(--text-1)', fontSize: 'var(--text-caption)' }}>
          Filters apply to the current view only. Original logs are preserved.
        </p>
      </div>
    </div>
  );
}
