import { Download, FileText, FileJson, Settings } from 'lucide-react';
import { useState } from 'react';

export function ExportTool() {
  const [format, setFormat] = useState<'txt' | 'csv' | 'json'>('txt');
  const [includeTimestamps, setIncludeTimestamps] = useState(true);
  const [includeSource, setIncludeSource] = useState(true);
  const [filterBy, setFilterBy] = useState<'all' | 'rx' | 'tx' | 'errors'>('all');

  const handleExport = () => {
    console.log('Exporting with:', { format, includeTimestamps, includeSource, filterBy });
    // In a real app, this would trigger the export
  };

  return (
    <div className="p-4 space-y-4">
      {/* Format Selection */}
      <div>
        <label className="block mb-2">Export Format</label>
        <div className="space-y-1">
          {[
            { value: 'txt' as const, label: 'Plain Text (.txt)', icon: FileText },
            { value: 'csv' as const, label: 'CSV (.csv)', icon: FileText },
            { value: 'json' as const, label: 'JSON (.json)', icon: FileJson },
          ].map(({ value, label, icon: Icon }) => (
            <button
              key={value}
              onClick={() => setFormat(value)}
              className="w-full px-3 py-2 rounded flex items-center gap-3 transition-colors"
              style={{
                background: format === value ? 'var(--accent-2)' : 'var(--bg-0)',
                color: format === value ? 'white' : 'var(--text-1)',
                border: `1px solid ${format === value ? 'var(--accent-2)' : 'var(--border)'}`,
              }}
            >
              <Icon size={16} />
              <span>{label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Filter Options */}
      <div>
        <label className="block mb-2">Messages to Export</label>
        <select
          value={filterBy}
          onChange={(e) => setFilterBy(e.target.value as any)}
          className="w-full px-3 py-2 rounded outline-none"
          style={{
            background: 'var(--bg-0)',
            color: 'var(--text-0)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius-input)'
          }}
        >
          <option value="all">All Messages</option>
          <option value="rx">RX Only</option>
          <option value="tx">TX Only</option>
          <option value="errors">Errors Only</option>
        </select>
      </div>

      {/* Export Options */}
      <div>
        <label className="block mb-2">
          <Settings size={14} className="inline mr-1" />
          Options
        </label>
        <div className="space-y-2">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={includeTimestamps}
              onChange={(e) => setIncludeTimestamps(e.target.checked)}
              className="w-4 h-4"
            />
            <span>Include Timestamps</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={includeSource}
              onChange={(e) => setIncludeSource(e.target.checked)}
              className="w-4 h-4"
            />
            <span>Include Source (RX/TX)</span>
          </label>
        </div>
      </div>

      {/* Export Stats */}
      <div 
        className="p-3 rounded"
        style={{ 
          background: 'var(--bg-0)',
          border: '1px solid var(--border)'
        }}
      >
        <div style={{ color: 'var(--text-2)', fontSize: 'var(--text-caption)' }}>
          Export Preview
        </div>
        <div className="mt-2 space-y-1" style={{ fontSize: 'var(--text-caption)' }}>
          <div className="flex justify-between">
            <span style={{ color: 'var(--text-2)' }}>Total Messages:</span>
            <span style={{ color: 'var(--text-0)' }}>124</span>
          </div>
          <div className="flex justify-between">
            <span style={{ color: 'var(--text-2)' }}>Estimated Size:</span>
            <span style={{ color: 'var(--text-0)' }}>~18 KB</span>
          </div>
        </div>
      </div>

      {/* Export Button */}
      <button
        onClick={handleExport}
        className="w-full px-4 py-2 rounded flex items-center justify-center gap-2 transition-colors"
        style={{
          background: 'var(--accent)',
          color: 'white',
        }}
      >
        <Download size={16} />
        Export to {format.toUpperCase()}
      </button>
    </div>
  );
}
