import { Send, RotateCcw } from 'lucide-react';
import { useState } from 'react';

interface SendToolProps {
  isConnected: boolean;
}

export function SendTool({ isConnected }: SendToolProps) {
  const [message, setMessage] = useState('');
  const [hexMode, setHexMode] = useState(false);
  const [addCR, setAddCR] = useState(true);
  const [addLF, setAddLF] = useState(true);

  const commonCommands = [
    { label: 'Status', value: 'CMD: READ_STATUS' },
    { label: 'Reset', value: 'CMD: RESET_DEVICE' },
    { label: 'Get Config', value: 'CMD: GET_CONFIG' },
    { label: 'Start Log', value: 'CMD: START_LOGGING' },
    { label: 'Stop Log', value: 'CMD: STOP_LOGGING' },
  ];

  const handleSend = () => {
    if (!message.trim() || !isConnected) return;
    // In a real app, this would send to the serial port
    console.log('Sending:', message);
    setMessage('');
  };

  return (
    <div className="p-4 space-y-4">
      {/* Quick Commands */}
      <div>
        <label className="block mb-2">Quick Commands</label>
        <div className="space-y-1">
          {commonCommands.map((cmd) => (
            <button
              key={cmd.label}
              onClick={() => setMessage(cmd.value)}
              disabled={!isConnected}
              className="w-full px-3 py-2 rounded text-left transition-colors hover:opacity-80 disabled:opacity-40"
              style={{
                background: 'var(--bg-0)',
                color: 'var(--text-1)',
                border: '1px solid var(--border)'
              }}
            >
              {cmd.label}
            </button>
          ))}
        </div>
      </div>

      {/* Message Input */}
      <div>
        <label className="block mb-2">Message</label>
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type your message..."
          disabled={!isConnected}
          rows={4}
          className="w-full px-3 py-2 rounded resize-none outline-none disabled:opacity-40"
          style={{
            background: 'var(--bg-0)',
            color: 'var(--text-0)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius-input)',
            fontFamily: hexMode ? 'var(--font-mono)' : 'inherit'
          }}
        />
      </div>

      {/* Options */}
      <div className="space-y-2">
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={hexMode}
            onChange={(e) => setHexMode(e.target.checked)}
            className="w-4 h-4"
          />
          <span>Hex Mode</span>
        </label>
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={addCR}
            onChange={(e) => setAddCR(e.target.checked)}
            className="w-4 h-4"
          />
          <span>Add CR (\\r)</span>
        </label>
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={addLF}
            onChange={(e) => setAddLF(e.target.checked)}
            className="w-4 h-4"
          />
          <span>Add LF (\\n)</span>
        </label>
      </div>

      {/* Actions */}
      <div className="flex gap-2">
        <button
          onClick={handleSend}
          disabled={!isConnected || !message.trim()}
          className="flex-1 px-4 py-2 rounded flex items-center justify-center gap-2 transition-colors disabled:opacity-40"
          style={{
            background: 'var(--accent)',
            color: 'white',
          }}
        >
          <Send size={16} />
          Send
        </button>
        <button
          onClick={() => setMessage('')}
          className="px-4 py-2 rounded transition-colors hover:opacity-80"
          style={{
            background: 'transparent',
            color: 'var(--text-1)',
            border: '1px solid var(--border)'
          }}
        >
          <RotateCcw size={16} />
        </button>
      </div>
    </div>
  );
}
