import { useState, useEffect } from 'react';
import { TopBar } from '@/app/components/TopBar';
import { LeftSidebar } from '@/app/components/LeftSidebar';
import { MessageStream } from '@/app/components/MessageStream';
import { RightToolDock } from '@/app/components/RightToolDock';
import { BottomStatusBar } from '@/app/components/BottomStatusBar';
import { ConnectDialog } from '@/app/components/ConnectDialog';
import { mockDevices, mockSessions, mockListeners, generateMockLogs } from '@/app/data/mockData';
import { Session, LogMessage, ToolType, Device, Listener } from '@/app/types';

export default function App() {
  const [sessions, setSessions] = useState<Session[]>(mockSessions);
  const [listeners] = useState<Listener[]>(mockListeners);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(mockSessions[0]?.id || null);
  const [logs, setLogs] = useState<LogMessage[]>(generateMockLogs(50));
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTool, setActiveTool] = useState<ToolType>(null);
  const [showConnectDialog, setShowConnectDialog] = useState(false);
  const [devices] = useState<Device[]>(mockDevices);
  const [showTimestamp, setShowTimestamp] = useState(true);
  const [autoSaveEnabled] = useState(true);
  const [notifications] = useState([
    { id: '1', type: 'warning' as const, message: 'High CPU usage detected' }
  ]);

  const activeSession = sessions.find(s => s.id === activeSessionId) || null;

  // Simulate real-time log streaming
  useEffect(() => {
    if (!activeSession || activeSession.status !== 'connected') return;

    const interval = setInterval(() => {
      const newLogs = generateMockLogs(1);
      setLogs(prev => [...prev, ...newLogs]);
      
      // Update session stats
      setSessions(prev => prev.map(s => 
        s.id === activeSessionId 
          ? { ...s, rxBytes: s.rxBytes + Math.floor(Math.random() * 100) }
          : s
      ));
    }, 3000);

    return () => clearInterval(interval);
  }, [activeSession, activeSessionId]);

  const handleConnect = (port: string, baudRate: number, name: string) => {
    const existingSession = sessions.find(s => s.port === port);
    
    if (existingSession) {
      setActiveSessionId(existingSession.id);
      setSessions(prev => prev.map(s => 
        s.id === existingSession.id 
          ? { ...s, status: 'connected', startTime: new Date() }
          : s
      ));
    } else {
      const newSession: Session = {
        id: `session-${Date.now()}`,
        name,
        port,
        baudRate,
        status: 'connected',
        startTime: new Date(),
        rxBytes: 0,
        txBytes: 0,
      };
      setSessions(prev => [...prev, newSession]);
      setActiveSessionId(newSession.id);
      setLogs(generateMockLogs(10)); // Fresh logs for new session
    }
  };

  const handleDisconnect = () => {
    if (!activeSessionId) return;
    setSessions(prev => prev.map(s => 
      s.id === activeSessionId ? { ...s, status: 'disconnected' } : s
    ));
  };

  const handleClear = () => {
    setLogs([]);
  };

  const handleExport = () => {
    setActiveTool('export');
  };

  const handleDeviceClick = (device: Device) => {
    setShowConnectDialog(true);
  };

  const filteredLogs = logs.filter(log => 
    !searchQuery || log.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-screen flex flex-col overflow-hidden">
      {/* Top Bar */}
      <TopBar
        activeSession={activeSession}
        onConnect={() => setShowConnectDialog(true)}
        onDisconnect={handleDisconnect}
        onClear={handleClear}
        onExport={handleExport}
      />

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar */}
        <LeftSidebar
          devices={devices}
          sessions={sessions}
          listeners={listeners}
          activeSessionId={activeSessionId}
          onSessionSelect={setActiveSessionId}
          onDeviceClick={handleDeviceClick}
        />

        {/* Center Workspace */}
        <MessageStream
          logs={filteredLogs}
          session={activeSession}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          showTimestamp={showTimestamp}
        />

        {/* Right Tool Dock */}
        <RightToolDock
          activeTool={activeTool}
          onToolChange={setActiveTool}
          isConnected={activeSession?.status === 'connected'}
        />
      </div>

      {/* Bottom Status Bar */}
      <BottomStatusBar
        autoSaveEnabled={autoSaveEnabled}
        notifications={notifications}
      />

      {/* Connect Dialog */}
      <ConnectDialog
        isOpen={showConnectDialog}
        devices={devices}
        onClose={() => setShowConnectDialog(false)}
        onConnect={handleConnect}
      />
    </div>
  );
}