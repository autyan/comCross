import { Device, LogMessage, Session, Listener } from '@/app/types';

export const mockDevices: Device[] = [
  { port: '/dev/ttyUSB0', name: 'STM32 Debug', manufacturer: 'STMicroelectronics', isFavorite: true },
  { port: '/dev/ttyUSB1', name: 'Arduino Uno', manufacturer: 'Arduino', isFavorite: true },
  { port: '/dev/ttyACM0', name: 'ESP32 DevKit', manufacturer: 'Espressif', isFavorite: false },
  { port: 'COM3', name: 'Nordic nRF52', manufacturer: 'Nordic Semiconductor', isFavorite: false },
  { port: 'COM5', name: 'FTDI USB Serial', manufacturer: 'FTDI', isFavorite: false },
];

export const mockListeners: Listener[] = [
  {
    id: 'listener-1',
    name: 'TCP Server',
    protocol: 'TCP',
    port: 8080,
    status: 'listening',
    startTime: new Date(Date.now() - 1000 * 60 * 60),
  },
  {
    id: 'listener-2',
    name: 'UDP Receiver',
    protocol: 'UDP',
    port: 9000,
    status: 'listening',
    startTime: new Date(Date.now() - 1000 * 60 * 30),
  },
];

export const mockSessions: Session[] = [
  // Standalone serial sessions
  {
    id: 'session-1',
    name: 'STM32 Debug',
    port: '/dev/ttyUSB0',
    baudRate: 115200,
    status: 'connected',
    startTime: new Date(Date.now() - 1000 * 60 * 45),
    rxBytes: 524288,
    txBytes: 8192,
  },
  {
    id: 'session-2',
    name: 'Arduino Uno',
    port: '/dev/ttyUSB1',
    baudRate: 9600,
    status: 'connected',
    startTime: new Date(Date.now() - 1000 * 60 * 15),
    rxBytes: 12048,
    txBytes: 256,
  },
  // TCP listener child sessions
  {
    id: 'session-tcp-1',
    name: 'Client 192.168.1.100',
    port: '192.168.1.100:54321',
    baudRate: 0,
    status: 'connected',
    startTime: new Date(Date.now() - 1000 * 60 * 20),
    rxBytes: 45678,
    txBytes: 12345,
    listenerId: 'listener-1',
  },
  {
    id: 'session-tcp-2',
    name: 'Client 192.168.1.101',
    port: '192.168.1.101:54322',
    baudRate: 0,
    status: 'connected',
    startTime: new Date(Date.now() - 1000 * 60 * 5),
    rxBytes: 8765,
    txBytes: 4321,
    listenerId: 'listener-1',
  },
  // UDP listener child sessions
  {
    id: 'session-udp-1',
    name: 'Source 10.0.0.50',
    port: '10.0.0.50:12345',
    baudRate: 0,
    status: 'connected',
    startTime: new Date(Date.now() - 1000 * 60 * 10),
    rxBytes: 98765,
    txBytes: 0,
    listenerId: 'listener-2',
  },
];

export const generateMockLogs = (count: number = 50): LogMessage[] => {
  const messages = [
    { source: 'SYSTEM' as const, content: 'System initialized', type: 'normal' as const },
    { source: 'RX' as const, content: '[INFO] Peripheral ready', type: 'normal' as const },
    { source: 'RX' as const, content: '[DEBUG] ADC reading: 3.287V', type: 'normal' as const },
    { source: 'TX' as const, content: 'CMD: READ_STATUS', type: 'normal' as const },
    { source: 'RX' as const, content: 'STATUS: OK (0x00)', type: 'normal' as const },
    { source: 'RX' as const, content: '[WARN] Temperature threshold exceeded: 78.5C', type: 'warning' as const },
    { source: 'ERROR' as const, content: '[ERROR] I2C communication timeout', type: 'error' as const },
    { source: 'RX' as const, content: 'Sensor data: X=0.245, Y=-0.127, Z=0.982', type: 'normal' as const },
    { source: 'TX' as const, content: 'CMD: RESET_DEVICE', type: 'normal' as const },
    { source: 'SYSTEM' as const, content: 'Connection established', type: 'normal' as const },
    { source: 'RX' as const, content: '[INFO] Firmware v2.3.1-beta', type: 'highlight' as const },
    { source: 'RX' as const, content: 'Battery voltage: 3.764V (92%)', type: 'normal' as const },
    { source: 'RX' as const, content: 'GPS Fix: Lat 37.7749, Lon -122.4194', type: 'normal' as const },
    { source: 'TX' as const, content: 'CMD: GET_CONFIG', type: 'normal' as const },
    { source: 'RX' as const, content: 'CONFIG: mode=auto, interval=1000ms', type: 'normal' as const },
    { source: 'ERROR' as const, content: '[ERROR] Memory allocation failed', type: 'error' as const },
    { source: 'RX' as const, content: '[DEBUG] Free heap: 45312 bytes', type: 'normal' as const },
    { source: 'RX' as const, content: 'WiFi connected: SSID=DevNet, RSSI=-42dBm', type: 'normal' as const },
    { source: 'RX' as const, content: '[INFO] Task scheduler started', type: 'normal' as const },
    { source: 'TX' as const, content: 'CMD: START_LOGGING', type: 'normal' as const },
  ];

  const logs: LogMessage[] = [];
  const now = Date.now();

  for (let i = 0; i < count; i++) {
    const msg = messages[i % messages.length];
    logs.push({
      id: `log-${i}`,
      timestamp: new Date(now - (count - i) * 2000),
      source: msg.source,
      content: msg.content,
      type: msg.type,
    });
  }

  return logs;
};