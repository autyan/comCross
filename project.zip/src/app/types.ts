export interface Session {
  id: string;
  name: string;
  port: string;
  baudRate: number;
  status: 'connected' | 'disconnected';
  startTime?: Date;
  rxBytes: number;
  txBytes: number;
  listenerId?: string; // Reference to parent listener if this is a TCP/UDP session
}

export interface Listener {
  id: string;
  name: string;
  protocol: 'TCP' | 'UDP';
  port: number;
  status: 'listening' | 'stopped';
  startTime?: Date;
}

export interface LogMessage {
  id: string;
  timestamp: Date;
  source: 'RX' | 'TX' | 'SYSTEM' | 'ERROR';
  content: string;
  type: 'normal' | 'error' | 'warning' | 'highlight';
}

export interface Device {
  port: string;
  name: string;
  manufacturer?: string;
  isFavorite: boolean;
}

export type ToolType = 'send' | 'filter' | 'highlight' | 'export' | null;

export interface FilterRule {
  id: string;
  pattern: string;
  isRegex: boolean;
  enabled: boolean;
}

export interface HighlightRule {
  id: string;
  pattern: string;
  isRegex: boolean;
  color: string;
  enabled: boolean;
}